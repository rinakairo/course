package tables;

public enum Role {  //вход под админом или пользователем
    ADMIN, USER
}
