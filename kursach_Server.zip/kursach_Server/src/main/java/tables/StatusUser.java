package tables;

public enum StatusUser {  //пользователель может быть забанен
    NORMAL, BANNED
}
