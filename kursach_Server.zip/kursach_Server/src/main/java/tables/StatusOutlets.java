package tables;

public enum  StatusOutlets {  //помещения свободные или арендованные
    FREE, ARENDED
}
