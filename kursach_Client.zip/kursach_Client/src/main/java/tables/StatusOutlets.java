package tables;

public enum  StatusOutlets {  //статус помещения
    FREE, ARENDED
}
