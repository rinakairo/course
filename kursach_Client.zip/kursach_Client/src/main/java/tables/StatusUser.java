package tables;

public enum StatusUser { //статус пользователя
    NORMAL, BANNED
}
