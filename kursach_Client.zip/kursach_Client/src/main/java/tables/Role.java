package tables;

public enum Role {  //админ или пользователь
    ADMIN, USER
}
